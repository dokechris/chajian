<?php
return array (
  'theme' => 
  array (
    'logo' => 
    array (
      'bpic' => 'template/conch/asset/img/logo_black.png',
      'wpic' => 'template/conch/asset/img/logo_white.png',
      'icon' => 'template/conch/asset/img/favicon.png',
      'webapp' => 'template/conch/asset/img/ios_fav.png',
    ),
    'lazy' => 'template/conch/asset/img/load.gif',
    'tj' => 
    array (
      'btn' => '1',
    ),
    'head' => 
    array (
      'text' => '',
    ),
    'foot' => 
    array (
      'text' => '<p>æ¯”è袭¾ƒè¾“å…¥çš„ézhidaoªŒè¯ç å’Œå®žé™…ç”Ÿæˆçš„éªŒè¯ç æ˜¯å¦ç›¸å</p>
<p>æ¯”è袭¾ƒè¾“å…¥çš„ézhidaoªŒè¯ç å’Œå®žé™…ç”Ÿæˆçš„éªŒè¯ç æ˜¯å¦ç›¸å</p>',
    ),
    'type' => 
    array (
      'hom' => '1,2,3,4',
      'meunbtn' => '1',
      'meunid' => '1,2,3,4',
      'meunys' => 'one',
      'ht' => '1,2',
      'ho' => '3,4',
      'hb' => '999',
      'zb' => '999',
      'mx' => '999',
    ),
    'vod' => 
    array (
      'hnum' => '12',
      'num' => '6',
    ),
    'notice' => 
    array (
      'btn' => '1',
      'text' => 'æ¯”è袭¾ƒè¾“å…¥çš„ézhidaoªŒè¯ç å’Œå®žé™…ç”Ÿæˆçš„éªŒè¯ç æ˜¯å¦ç›¸å',
    ),
    'hotvod' => 
    array (
      'title' => 'Ani ohev otach',
      'num' => '12',
      'btn' => '1',
    ),
    
    'mrgx' => 
    array (
      'mtitle' => '今日更新',
      'mnum' => '12',
      'mbtn' => '1',
    ),
    
    'art' => 
    array (
      'hbtn' => '1',
      'htitle' => '热点资讯',
      'hnum' => '6',
    ),
    'topic' => 
    array (
      'hbtn' => '1',
      'hnum' => '6',
      'title' => '专题',
      'btn' => '1',
    ),
    'actor' => 
    array (
      'hbtn' => '1',
      'htitle' => '荧幕热星',
      'title' => '明星',
      'btn' => '1',
    ),
    'rank' => 
    array (
      'hbtn' => '1',
      'hby' => 'week',
      'hid' => '1,2,3,4',
      'vby' => 'week',
      'btn' => '1',
      'title' => '排行榜',
      'num' => '6',
      'id' => '1,2,3,4,6,7',
    ),
    'links' => 
    array (
      'btn' => '1',
      'title' => '友情链接',
      'num' => '30',
    ),
    'banner' => 
    array (
      'btn' => '1',
      'ms' => 'small',
      'smbg' => '1',
      'bgstyle' => '',
    ),
    'lbbanner' => 
    array (
      'btn' => '1',
    ),
    'search' => 
    array (
      'text' => '海量影片精彩看不停',
      'lxbtn' => '1',
    ),
    'play' => 
    array (
      'height' => '56.25',
      'adbtn' => '1',
      'nbtn' => '1',
      'notice' => '<li><span class=\'mytip\'>提醒</span>不要轻易相信视频中的广告，谨防上当受骗!</li>
<li>__j&= y+ y* jv+ yy-v v &_wE!" j17＄T 7MPC NU＄E- Ej&v-_O*K^ y。</li>
<li>视频载入__j&= y+ y* jv+ yy-v v &_wE!" j17＄T 7MPC NU＄E- Ej&v-_O*K^ y。</li>',
    ),
    'show' => 
    array (
      'filter' => 'a|b|c|d|e',
    ),
    'playlink' => 
    array (
      'btn' => '0',
    ),
    'nav' => 
    array (
      'id' => '1,2,3,4,5,22',
      'zdybtn' => '0',
      'zdybtn1' => '0',
      'zdyname1' => '音乐MV',
      'zdylink1' => '/',
      'zdypic1' => 'template/conch/asset/img/ios_fav.png',
      'zdybtn2' => '0',
      'zdyname2' => '',
      'zdylink2' => '',
      'zdypic2' => '',
      'zdybtn3' => '0',
      'zdyname3' => '',
      'zdylink3' => '',
      'zdypic3' => '',
      'zdybtn4' => '0',
      'zdyname4' => '',
      'zdylink4' => '',
      'zdypic4' => '',
    ),
    'rtnav' => 
    array (
      'ym' => 'a|c|e|h|i',
      'zdybtn1' => '0',
      'zdyname1' => '',
      'zdylink1' => '',
      'zdybtn2' => '0',
      'zdyname2' => '',
      'zdylink2' => '',
    ),
    'fnav' => 
    array (
      'btn' => '1',
      'id' => '1,2',
      'ym' => 'h|b|h|g',
      'zdybtn1' => '0',
      'zdyname1' => '',
      'zdylink1' => '',
      'zdybtn2' => '0',
      'zdyname2' => '',
      'zdylink2' => '',
    ),
    'share' => 
    array (
      'bdbtn' => '0',
      'api' => 'bd',
      'link' => '',
      'apiurl' => '',
      'tok' => '',
      'term' => 'long',
    ),
    'qq' => 
    array (
      'btn' => '1',
      'title' => '联系QQ',
      'link' => 'http://wpa.qq.com/msgrd?v=3&uin=888111222&site=qq&menu=yes',
    ),
    'weixin' => 
    array (
      'btn' => '1',
      'btntext' => '7MPC NU＄E- Ej&v-_O*K^ y',
      'qrcode' => 'template/conch/asset/img/ewm.jpg',
      'title' => '关注微信观看',
      'text' => '<p>长按识别二维码或微信扫码关注</p><p>关注后回复片名即可</p><p>或微信搜索微信名：<span class=\'mycol\'>pc82838</span></p>',
    ),
    'zans' => 
    array (
      'btn' => '1',
      'qrcode' => 'template/conch/asset/img/dsm.jpg',
      'title' => '^*&&Ijghjh9*66',
      'text' => '<p>长按识别二维码或微信扫描二维码</p><p>ojjjl，多少都是支持</p>',
    ),
    'apps' => 
    array (
      'btn' => '1',
      'link' => '',
    ),
    'map' => 
    array (
      'btn' => '1',
      'title' => '最近更新',
      'id' => '',
    ),
    'color' => 
    array (
      'select' => '0',
      'sbtn' => '1',
      'ms' => 'black',
      'mbtn' => '1',
    ),
    'role' => 
    array (
      'title' => '角色',
      'btn' => '1',
    ),
    'plot' => 
    array (
      'title' => '剧情',
      'btn' => '1',
    ),
    'gbook' => 
    array (
      'title' => '留言',
    ),
    'user' => 
    array (
      'title' => '会员',
    ),
    'font' => '0',
    'seos' => 
    array (
      'index_name' => '',
      'index_key' => '',
      'index_des' => '',
      'detail_name' => '',
      'detail_key' => '',
      'detail_des' => '',
      'play_name' => '',
      'play_key' => '',
      'play_des' => '',
      'down_name' => '',
      'down_key' => '',
      'down_des' => '',
      'arti_name' => '',
      'arti_key' => '',
      'arti_des' => '',
      'artd_name' => '',
      'artd_key' => '',
      'artd_des' => '',
      'topic_name' => '',
      'topic_key' => '',
      'topic_des' => '',
      'topicd_name' => '',
      'topicd_key' => '',
      'topicd_des' => '',
    ),
    'ads' => 
    array (
      'btn' => '1',
      'bottom' => 
      array (
        'btn' => '0',
        'content' => '<a href="#"><img src="http://yanshi.sdpiyou.com/ads-example.jpg" /></a>',
      ),
      'all' => 
      array (
        'btn' => '1',
        'content' => '<a href="#"><img src="http://yanshi.sdpiyou.com/ads-example.jpg" /></a>',
      ),
      'banner' => 
      array (
        'btn' => '0',
        'tbtn' => '0',
        'title' => '',
        'sub' => '',
        'link' => '',
        'pic' => '',
      ),
      'vod_w' => 
      array (
        'btn' => '1',
        'content' => '<a href="#"><img src="http://yanshi.sdpiyou.com/ads-example.jpg" /></a>',
      ),
      'vod_r' => 
      array (
        'btn' => '1',
        'content' => '<a href="#"><img src="http://yanshi.sdpiyou.com/ads-example.jpg" /></a>',
      ),
      'play' => 
      array (
        'btn' => '1',
        'tbtn' => '1',
        'title' => '测试广告',
        'link' => '',
        'pic' => 'http://yanshi.sdpiyou.com/ads-example.jpg',
      ),
      'search_v' => 
      array (
        'btn' => '1',
        'tbtn' => '1',
        'title' => '测试广告',
        'sub' => '测试广告',
        'link' => '',
        'pic' => 'http://yanshi.sdpiyou.com/ads-example.jpg',
      ),
      'art_w' => 
      array (
        'btn' => '1',
        'content' => '<a href="#"><img src="http://yanshi.sdpiyou.com/ads-example.jpg" /></a>',
      ),
      'art_r' => 
      array (
        'btn' => '1',
        'content' => '<a href="#"><img src="http://yanshi.sdpiyou.com/ads-example.jpg" /></a>',
      ),
      'artlist' => 
      array (
        'btn' => '1',
        'tbtn' => '1',
        'title' => '测试广告',
        'link' => '',
        'pic' => 'http://yanshi.sdpiyou.com/ads-example.jpg',
      ),
      'user' => 
      array (
        'btn' => '1',
        'pic' => 'http://yanshi.sdpiyou.com/ads-example.jpg',
      ),
    ),
  ),
);